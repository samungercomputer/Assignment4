package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener,GestureDetector.OnDoubleTapListener {

    private EditText dollar;
    private TextView pound;
    private TextView euro;
    private TextView peso;
    private TextView yen;
    private GestureDetector detector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dollar = (EditText) findViewById(R.id.editTextTextPersonName2);

        TextChangeHandler tch = new TextChangeHandler();
        dollar.addTextChangedListener(tch);
        detector = new GestureDetector(this,this);
        detector.setOnDoubleTapListener(this);
    }

    public void convert() {
        try {
            String dolstring = dollar.getText().toString();
            float dlr = Float.parseFloat(dolstring);
            TextView pound = (TextView) findViewById(R.id.textView4);
            TextView euro = (TextView) findViewById(R.id.textView5);
            TextView peso = (TextView) findViewById(R.id.textView6);
            TextView yen = (TextView) findViewById(R.id.textView7);
            EditText dollar = (EditText) findViewById(R.id.editTextTextPersonName2);
            if (dlr < 0){
                pound.setText(Double.toString(0));
                euro.setText(Double.toString(0));
                peso.setText(Double.toString(0));
                yen.setText(Double.toString(0));
                dollar.setText(Double.toString(0));
            }else {
                pound.setText(Double.toString((.86 * dlr)));
                euro.setText(Double.toString(dlr));
                peso.setText(Double.toString(19.8 * dlr));
                yen.setText(Double.toString(147.46 * dlr));

            }
        }
        catch (NumberFormatException nfe){
            TextView pound = (TextView) findViewById(R.id.textView4);
            TextView euro = (TextView) findViewById(R.id.textView5);
            TextView peso = (TextView) findViewById(R.id.textView6);
            TextView yen = (TextView) findViewById(R.id.textView7);
            pound.setText("pound");
            euro.setText("euro");
            peso.setText("peso");
            yen.setText("yen");
        }
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        float diry = motionEvent1.getY() - motionEvent.getY();
        if ((Math.abs(diry)<70) && (Math.abs(v1)<70)) {
            if (diry > 0) {
                onScrollBottom();
            } else {
                onScrollTop();
            }

        }


        return true;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {

        float diry = motionEvent1.getY() - motionEvent.getY();
        if ((Math.abs(diry)>1000) && (Math.abs(v1)>1000)) {
            if (diry > 0) {
                onSwipeBottom();
            } else {
                onSwipeTop();
            }

        }


        return true;
    }
    private void onSwipeTop(){
        EditText dollar = (EditText) findViewById(R.id.editTextTextPersonName2);
        String dolstring = dollar.getText().toString();
        float dlr = Float.parseFloat(dolstring);
        dollar.setText(Double.toString(dlr+1));
        convert();
    }
    private void onSwipeBottom(){
        EditText dollar = (EditText) findViewById(R.id.editTextTextPersonName2);
        String dolstring = dollar.getText().toString();
        float dlr = Float.parseFloat(dolstring);
        dollar.setText(Double.toString(dlr-1));
        convert();

    }

    private void onScrollTop(){
        EditText dollar = (EditText) findViewById(R.id.editTextTextPersonName2);
        String dolstring = dollar.getText().toString();
        float dlr = Float.parseFloat(dolstring);
        dollar.setText(Double.toString(dlr+(.1)));
        convert();
    }
    private void onScrollBottom() {
        EditText dollar = (EditText) findViewById(R.id.editTextTextPersonName2);
        String dolstring = dollar.getText().toString();
        float dlr = Float.parseFloat(dolstring);
        dollar.setText(Double.toString(dlr - (.1)));
        convert();
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        detector.onTouchEvent(event);
        return true;
    }

    private class TextChangeHandler implements TextWatcher {
        public void afterTextChanged(Editable e) {
            convert();
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int count, int after) {

        }

    }
}
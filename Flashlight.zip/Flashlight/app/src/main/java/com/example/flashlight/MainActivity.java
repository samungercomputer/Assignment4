package com.example.flashlight;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.hardware.Camera;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener,GestureDetector.OnDoubleTapListener {
    private Switch swish;
    private Camera camera;
    private EditText listen;
    private GestureDetector detector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listen = (EditText) findViewById(R.id.editTextTextPersonName2);
        TextChangeHandler tch = new TextChangeHandler();
        listen.addTextChangedListener(tch);
        detector = new GestureDetector(this,this);
        detector.setOnDoubleTapListener(this);

        Switch swish = (Switch) findViewById(R.id.switch1);
        camera = camera.open();
        Camera.Parameters parameters = camera.getParameters();

        swish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                parameters.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                camera.setParameters(parameters);
                camera.startPreview();
            }
        });


    }

    public void typer() {
        String possible = listen.getText().toString();
        Switch swish = (Switch) findViewById(R.id.switch1);

        if (possible.equals("ON")) {
            swish.setChecked(true);
        }
        if (possible.equals("OFF")) {
            swish.setChecked(false);
        }

    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {


    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {

        float diry = motionEvent1.getY() - motionEvent.getY();
        if ((Math.abs(diry)>1000) && (Math.abs(v1)>1000)) {
            if (diry > 0) {
                onSwipeBottom();
            } else {
                onSwipeTop();
            }

        }


        return true;
    }
    private void onSwipeTop(){
        Switch swish = (Switch) findViewById(R.id.switch1);
        swish.setChecked(true);
    }
    private void onSwipeBottom(){
        Switch swish = (Switch) findViewById(R.id.switch1);
        swish.setChecked(false);
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        detector.onTouchEvent(event);
        return true;
    }

    private class TextChangeHandler implements TextWatcher {
        public void afterTextChanged(Editable e) {
            typer();
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int count, int after) {

        }

    }

}
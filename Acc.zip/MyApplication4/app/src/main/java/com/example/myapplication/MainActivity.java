package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;


public class MainActivity extends AppCompatActivity  {


    private double currentX;
    private double currentY;
    private double currentZ;
    private double prevX;
    private double prevY;
    private double prevZ;
    private TextView textView;
    private ProgressBar progressBar;
    private SeekBar seekBar;
    private WebView webview;
    private final String TAG = "MainActivity";
    private SensorManager sensorManager;
    Sensor sensor;
    private SensorEventListener SEL = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            float x = sensorEvent.values[0];
            float y = sensorEvent.values[1];
            float z = sensorEvent.values[2];

            currentX = Math.abs(x);
            currentY = Math.abs(y);
            currentZ = Math.abs(z);


            double changeX = Math.abs(currentX - prevX);
            double changeY = Math.abs(currentY - prevY);
            double changeZ = Math.abs(currentZ - prevZ);
            prevX = currentX;
            prevY = currentY;
            prevZ = currentZ;

            double total =(1+((Double.parseDouble((String) textView.getText()))/10));

            if (changeX > total ) {
                Log.d(TAG, "X changed by "+changeX);
                Context context = getApplicationContext();
                CharSequence text = "X changed by"+changeX;
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
            if (changeY > total) {
                Log.d(TAG, "Y changed by "+changeY);
                Context context = getApplicationContext();
                CharSequence text = "Y changed by"+changeY;
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
            if (changeZ > total) {
                Log.d(TAG, "Z changed by "+changeZ);
                Context context = getApplicationContext();
                CharSequence text = "Z changed by"+changeZ;
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
//             Double[] arr = {changeX, changeY, changeZ};
//            double forurl = Collections.max(Arrays.asList(arr));
//            if ((forurl > total) && (forurl == changeX)){
//                webview = (WebView) findViewById(R.id.wv);
//                webview.setWebViewClient(new WebViewClient());
//                webview.loadUrl("https://www.ecosia.org/");
//            }
//            if ((forurl > total) && (forurl == changeY)){
//                webview = (WebView) findViewById(R.id.wv);
//                webview.setWebViewClient(new WebViewClient());
//                webview.loadUrl("https://www.dogpile.com/");
//            }
//
//            if ((forurl > total) && (forurl == changeZ)){
//                webview = (WebView) findViewById(R.id.wv);
//                webview.setWebViewClient(new WebViewClient());
//                webview.loadUrl("https://webb.nasa.gov/");
//            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }


    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    //        webview = (WebView) findViewById(R.id.wv);
//        webview.loadUrl("https://www.ecosia.org");
        textView = (TextView) findViewById(R.id.textView2);
        progressBar =(ProgressBar)findViewById(R.id.pb);
        seekBar = (SeekBar) findViewById(R.id.seekBar);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                progressBar.setProgress(i);
                textView.setText(""+i);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }




        protected void onResume () {
            super.onResume();
            sensorManager.registerListener(SEL, sensor, SensorManager.SENSOR_DELAY_NORMAL);
        }

        protected void onPause () {
            super.onPause();
            sensorManager.unregisterListener(SEL);
        }


}

